import { createServer } from 'http';
import { readFile, existsSync, mkdirSync, appendFile } from 'fs';
import { join } from 'path';
import EventEmitter from 'events';
import moment from 'moment';

const server = createServer((req, res) => {
  const url = req.url;
  const route = url === '/' ? 'home' : url.slice(1);

  const myEmitter = new EventEmitter();
  myEmitter.on('route-accessed', (route) => {
    console.log(`Route accessed: ${route}`);
    logEvent(`Route accessed: ${route}`);
  });
  myEmitter.emit('route-accessed', route);

  const viewsFolder = join(__dirname, 'views');
  const filePath = join(viewsFolder, route + '.html');

  readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/html' });
      res.write('<h1>Page not found</h1>');
      res.end();
    } else {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.write(data);
      res.end();
    }
  });


});

const port = 3000;
server.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

// Bonus: Log events to a daily log file
function logEvent(message) {
  const today = moment().format('YYYY-MM-DD');
  const logFolder = join(__dirname, 'logs');
  const logFile = join(logFolder, `${today}.log`);

  if (!existsSync(logFolder)) {
    mkdirSync(logFolder);
  }

  appendFile(logFile, `${moment().format('HH:mm:ss')} - ${message}\n`, (err) => {
    if (err) {
      console.error(`Error writing to log file: ${err}`);
    }
  });
}
